<section class="banner" data-scroll-index='0'>


  

    <div class="banner-overlay">

      <video autoplay muted loop>
      <source src="/images/background.mp4">
    </video>
    
      <div class="container">
        <div class="row">
          <div class="col-md-8 col-sm-12">
            <div class="banner-text">
              <h2 class="white">Conheça o app Calmind</h2>
              <h6 class="white">Recupere seu Foco e Produtividade</h6>
              <p class="banner-text white">Desafios, recompensas e suporte para te ajudar a reduzir o vício em dopamina
                e aproveitar mais a vida real. Baixe agora e comece sua transformação!</p>
              <ul>
                <li><a href="#"><img src="../images/playstore.png" class="wow fadeInUp" data-wow-delay="0.7s" /></a></li>
              </ul>
            </div>
          </div>
          <div class="col-md-4 col-sm-12"> <img src="images/celular-app.png" id="appimg" class="img-fluid wow fadeInUp" /> </div>
        </div>
      </div>
    </div>
  </section>